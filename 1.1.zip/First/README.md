MoodSphere
Project 1 - Mental Health Tracker - Moodsphere

            Coders:
Nadine- Authentication (log in)
Morgan- Home/Welcome page Design
Caitlin- Statistics (track entries)
Loralee- API & README

Objective: Create a functioning mental health tracker app.

Motivation: Mental Health awareness is becoming more and more prevalent in today's culture, we are as a society learning that we need to focus more on mental health. As a group we all feel we can relate in some way, whether it's depression or anxiety or just stressed out. It is an important project to us and something we felt we all would use or would like to use for various reasons.

Summary: We aim to create an app that will be useful in tracking an individuals' mental health. You will be required to create a login, scoring, tracking scores over time, include resources,etc.


API’s used:
1) MetaWeather

2) Forismatic

API’s considered:
1)AccuWeather

2)RapidAPI -Universal Inspirational Quotes



